# Validation record

Final review: 29 October 2026. Source retrievals are dated 28 October 2026.

## Executed checks

- `python3 build.py`: passed. Validated 36 unique modules, 180 substantive sessions, prerequisite references and acyclicity, resource references, project fields and non-negative activity budgets.
- `node --check src/app.js`: passed.
- `python3 tests/test_atlas.py`: **13 tests passed**. Includes all eight application views, desktop/mobile layout, all 36 module dialogs, searches, five route dependency closures, conservation of remaining activity minutes, study/rest settings, five numerical teaching models, mastery and persistence, escaped notes, progress import/export validation, partial capstone work, overdue recall and calendar line folding.
- Browser tests recorded no JavaScript errors or attempted external network requests.
- `git diff --check`: passed.

## Test scope and limitations

The installed Chromium browser blocks `file://` navigation by managed policy. Tests therefore served the exact single HTML artifact on a loopback HTTP server, with all external HTTP/HTTPS requests blocked. Direct file-origin storage behavior is **not verified** in this managed browser. The artifact contains no external script, stylesheet, font or image dependency and no server API; external learning links require internet access. The included test suite supports direct-file testing on a browser that permits it.

Desktop and mobile screenshots were inspected. This is functional and responsive testing, not a complete accessibility certification or exhaustive browser compatibility matrix.

No current job-advertisement sample was obtained: the runtime policy blocked major labor-market and employer destinations. The evidence ledger separates retrieved engineering/research sources from unverified market references and conditional future scenarios. Research domains were saved in an environment configuration draft; saving did not apply or publish them.

Lesson times, project budgets, review intervals and contingency are authored planning heuristics. The curriculum has not been tested in a longitudinal learner study and makes no employment guarantee.
